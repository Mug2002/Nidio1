# Academic Project 5sem

## Note
This repository contains the academic project for fictional company NIDIO, used in the fifth semester of the TADS course at the University of Nove de Julho.
## About
NIDIO is a fictional company that offers the service of technical support.

# Begin
## Site
   Html/Css with Bootstrap 3
## Legacy system
   Java
## Database
   Oracle 11g
   Modeling in DER

# Target
## Site
   Html/Css with Bootstrap 3 and PHP
## Complete System
   C#
   Modeling in UML
## New Database
   Oracle 11g
   Modeling in DER
